<?php

namespace App\Http\Controllers;

use App\Models\Ingredient;
use App\Models\Recipe;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class RecipeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['index', 'show']);
    }

    // Public recipe grid (Task 17-18)
    public function index(Request $request)
    {
        $query = Recipe::with('user')->latest();

        if ($search = $request->get('search')) {
            $query->search($search);
        }

        if ($category = $request->get('category')) {
            $query->byCategory($category);
        }

        $recipes = $query->paginate(12);

        // AJAX search returns partial view
        if ($request->ajax()) {
            return view('recipes._grid', compact('recipes'))->render();
        }

        $categories = Recipe::distinct()->pluck('category')->filter()->sort()->values();
        return view('recipes.index', compact('recipes', 'categories'));
    }

    // My recipes dashboard (Task 14)
    public function dashboard()
    {
        $recipes = auth()->user()->recipes()->latest()->paginate(10);
        return view('recipes.dashboard', compact('recipes'));
    }

    // Single recipe page (Task 18)
    public function show(Recipe $recipe)
    {
        $recipe->load(['user', 'ingredients', 'comments.user', 'likes', 'bookmarks']);
        return view('recipes.show', compact('recipe'));
    }

    // Create form (Task 15)
    public function create()
    {
        $ingredients = Ingredient::orderBy('category')->orderBy('name')->get()->groupBy('category');
        return view('recipes.create', compact('ingredients'));
    }

    // Store new recipe
    public function store(Request $request)
    {
        $validated = $this->validateRecipe($request);

        $validated['user_id'] = auth()->id();

        if ($request->hasFile('image')) {
            $validated['image'] = $request->file('image')->store('recipes', 'public');
        }

        $recipe = Recipe::create($validated);

        // Sync ingredients with pivot data
        if ($request->has('ingredients')) {
            $syncData = [];
            foreach ($request->ingredients as $ingredientData) {
                if (!empty($ingredientData['id'])) {
                    $syncData[$ingredientData['id']] = [
                        'quantity' => $ingredientData['quantity'] ?? null,
                        'unit'     => $ingredientData['unit'] ?? null,
                    ];
                }
            }
            $recipe->ingredients()->sync($syncData);
        }

        return redirect()->route('recipes.dashboard')
                         ->with('success', 'Recipe created successfully!');
    }

    // Edit form (Task 16)
    public function edit(Recipe $recipe)
    {
        $this->authorize('update', $recipe);
        $ingredients = Ingredient::orderBy('category')->orderBy('name')->get()->groupBy('category');
        return view('recipes.edit', compact('recipe', 'ingredients'));
    }

    // Update recipe
    public function update(Request $request, Recipe $recipe)
    {
        $this->authorize('update', $recipe);
        $validated = $this->validateRecipe($request);

        if ($request->hasFile('image')) {
            if ($recipe->image) Storage::disk('public')->delete($recipe->image);
            $validated['image'] = $request->file('image')->store('recipes', 'public');
        }

        $recipe->update($validated);

        if ($request->has('ingredients')) {
            $syncData = [];
            foreach ($request->ingredients as $ingredientData) {
                if (!empty($ingredientData['id'])) {
                    $syncData[$ingredientData['id']] = [
                        'quantity' => $ingredientData['quantity'] ?? null,
                        'unit'     => $ingredientData['unit'] ?? null,
                    ];
                }
            }
            $recipe->ingredients()->sync($syncData);
        }

        return redirect()->route('recipes.show', $recipe)
                         ->with('success', 'Recipe updated!');
    }

    public function destroy(Recipe $recipe)
    {
        $this->authorize('delete', $recipe);
        if ($recipe->image) Storage::disk('public')->delete($recipe->image);
        $recipe->delete();
        return redirect()->route('recipes.dashboard')
                         ->with('success', 'Recipe deleted.');
    }

    private function validateRecipe(Request $request): array
    {
        return $request->validate([
            'title'        => ['required', 'string', 'max:255'],
            'description'  => ['required', 'string'],
            'instructions' => ['required', 'string'],
            'image'        => ['nullable', 'image', 'max:2048'],
            'prep_time'    => ['required', 'integer', 'min:0'],
            'cook_time'    => ['required', 'integer', 'min:0'],
            'servings'     => ['required', 'integer', 'min:1'],
            'difficulty'   => ['required', 'in:easy,medium,hard'],
            'category'     => ['nullable', 'string', 'max:100'],
        ]);
    }
}
