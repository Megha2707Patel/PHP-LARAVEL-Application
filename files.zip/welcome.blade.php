<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Georgia, serif; background: #fafaf9; margin: 0; padding: 40px 20px; }
        .container { max-width: 580px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
        .header { background: #e67e22; padding: 40px 40px 30px; text-align: center; }
        .header h1 { color: white; font-size: 28px; margin: 0; }
        .header p { color: rgba(255,255,255,0.85); margin: 8px 0 0; font-family: sans-serif; }
        .body { padding: 40px; }
        .body h2 { color: #1c1917; font-size: 22px; }
        .body p { color: #57534e; line-height: 1.7; font-family: sans-serif; }
        .cta { display: block; background: #e67e22; color: white; text-decoration: none; text-align: center; padding: 14px 32px; border-radius: 10px; font-family: sans-serif; font-weight: 600; margin: 24px 0; }
        .footer { border-top: 1px solid #f5f5f4; padding: 20px 40px; text-align: center; color: #a8a29e; font-size: 12px; font-family: sans-serif; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🍽️ Recipe Share</h1>
            <p>Your culinary community awaits</p>
        </div>
        <div class="body">
            <h2>Welcome, {{ $user->name }}! 👋</h2>
            <p>
                We're thrilled to have you join Recipe Share — the community where food lovers
                come together to discover, create, and share amazing recipes.
            </p>
            <p>
                Your account is all set up and ready to go. Here's what you can do:
            </p>
            <ul style="color: #57534e; font-family: sans-serif; line-height: 2;">
                <li>🥘 <strong>Browse</strong> thousands of community recipes</li>
                <li>✍️ <strong>Create & share</strong> your own culinary creations</li>
                <li>❤️ <strong>Like & bookmark</strong> recipes to try later</li>
                <li>💬 <strong>Comment</strong> and connect with other food lovers</li>
            </ul>
            <a href="{{ config('app.url') }}" class="cta">
                Start Exploring Recipes →
            </a>
        </div>
        <div class="footer">
            <p>You received this email because you registered at Recipe Share.</p>
            <p>© {{ date('Y') }} Recipe Share. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
